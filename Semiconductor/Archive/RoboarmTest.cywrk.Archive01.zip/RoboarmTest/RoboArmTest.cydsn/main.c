
#include "project.h"
#include <stdbool.h>

int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    
    //multiplexer for the three potentiometers. not enough ADC ports so using three ports and multiplexer
    Pot_Vals_Start();
    ADC_Start();
    
    int16 Pot_1_Val;
    int16 Pot_2_Val;
    int16 Pot_3_Val;
    
    
    for(;;)
    {
    Pot_Vals_Select(0);
    CyDelay(25);
    ADC_StartConvert();
    ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
    Pot_1_Val = ADC_GetResult16();
    
    Pot_Vals_Select(1);
    CyDelay(25);
    ADC_StartConvert();
    ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
    Pot_2_Val = ADC_GetResult16();
    
    Pot_Vals_Select(2);
    CyDelay(25);
    ADC_StartConvert();
    ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
    Pot_3_Val = ADC_GetResult16();
    
    printf(Pot_1_Val);
    printf(Pot_2_Val);
    printf(Pot_3_Val);
    
    }
}

/* [] END OF FILE */
